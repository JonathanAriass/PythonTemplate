
def test_first_test():
    assert 1 == 1

if __name__ == "__main__":
    test_first_test()
